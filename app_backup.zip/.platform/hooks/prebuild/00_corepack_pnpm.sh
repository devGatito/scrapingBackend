#!/bin/bash
set -euo pipefail

echo "[prebuild] Enabling corepack and activating pnpm@10.20.0"
command -v corepack >/dev/null 2>&1 || { echo "corepack not found, installing via npm..."; npm i -g corepack; }
corepack enable
corepack prepare pnpm@10.20.0 --activate
pnpm --version
