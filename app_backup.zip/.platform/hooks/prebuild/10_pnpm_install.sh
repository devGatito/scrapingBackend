#!/bin/bash
set -euo pipefail

echo "[prebuild] Approving build scripts and installing deps with pnpm"
# Approve specific native builds that pnpm blocks by default
pnpm approve-builds canvas || true
# Install dependencies using the lockfile
pnpm install --frozen-lockfile --prefer-offline
